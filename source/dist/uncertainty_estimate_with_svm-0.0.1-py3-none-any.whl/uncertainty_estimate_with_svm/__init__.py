from . import ucf

name = 'uncertainty_estimate_with_svm'
